from django.apps import AppConfig


class ThesisConfig(AppConfig):
    name = 'thesis'
