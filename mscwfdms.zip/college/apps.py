from django.apps import AppConfig


class AllConfig(AppConfig):
    name = 'college'
